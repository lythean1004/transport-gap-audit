CREATE TABLE IF NOT EXISTS data_source (
  source_id VARCHAR PRIMARY KEY,
  owner VARCHAR NOT NULL,
  platform VARCHAR,
  source_url VARCHAR NOT NULL,
  license VARCHAR,
  terms_checked_at TIMESTAMPTZ,
  collection_method VARCHAR,
  key_variables VARCHAR,
  notes VARCHAR
);

CREATE TABLE IF NOT EXISTS source_provenance (
  artifact_id UUID PRIMARY KEY,
  source_id VARCHAR NOT NULL,
  source_record_id VARCHAR,
  retrieved_at TIMESTAMPTZ NOT NULL,
  request_url VARCHAR,
  raw_path VARCHAR NOT NULL,
  sha256 VARCHAR NOT NULL,
  license_snapshot VARCHAR,
  FOREIGN KEY (source_id) REFERENCES data_source(source_id)
);

CREATE TABLE IF NOT EXISTS api_snapshot (
  snapshot_id UUID PRIMARY KEY,
  source_id VARCHAR NOT NULL,
  observed_at TIMESTAMPTZ NOT NULL,
  request_key VARCHAR,
  http_status INTEGER,
  payload_path VARCHAR NOT NULL,
  payload_sha256 VARCHAR NOT NULL,
  parse_status VARCHAR NOT NULL,
  error_message VARCHAR
);

CREATE TABLE IF NOT EXISTS network_node (
  node_id VARCHAR PRIMARY KEY,
  node_type VARCHAR NOT NULL,
  name VARCHAR,
  lon DOUBLE NOT NULL,
  lat DOUBLE NOT NULL,
  source_id VARCHAR,
  valid_from TIMESTAMPTZ,
  valid_to TIMESTAMPTZ
);

CREATE TABLE IF NOT EXISTS network_edge (
  edge_id VARCHAR PRIMARY KEY,
  from_node_id VARCHAR NOT NULL,
  to_node_id VARCHAR NOT NULL,
  edge_type VARCHAR NOT NULL,
  length_m DOUBLE,
  base_duration_s DOUBLE,
  accessibility_profile JSON,
  source_id VARCHAR,
  FOREIGN KEY (from_node_id) REFERENCES network_node(node_id),
  FOREIGN KEY (to_node_id) REFERENCES network_node(node_id)
);

CREATE TABLE IF NOT EXISTS vehicle_observation (
  observation_id UUID PRIMARY KEY,
  observed_at TIMESTAMPTZ NOT NULL,
  route_id VARCHAR NOT NULL,
  stop_id VARCHAR NOT NULL,
  vehicle_id_hash VARCHAR,
  vehicle_type VARCHAR,
  is_low_floor BOOLEAN,
  arrival_seconds INTEGER,
  raw_snapshot_id UUID,
  UNIQUE(observed_at, route_id, stop_id, vehicle_id_hash)
);

CREATE TABLE IF NOT EXISTS elevator_asset (
  elevator_id VARCHAR PRIMARY KEY,
  station_id VARCHAR NOT NULL,
  name VARCHAR,
  path_role VARCHAR,
  source_id VARCHAR,
  valid_from TIMESTAMPTZ,
  valid_to TIMESTAMPTZ
);

CREATE TABLE IF NOT EXISTS elevator_observation (
  observation_id UUID PRIMARY KEY,
  elevator_id VARCHAR NOT NULL,
  observed_at TIMESTAMPTZ NOT NULL,
  status VARCHAR NOT NULL,
  failure_reason VARCHAR,
  raw_snapshot_id UUID,
  FOREIGN KEY (elevator_id) REFERENCES elevator_asset(elevator_id),
  UNIQUE(elevator_id, observed_at)
);

CREATE TABLE IF NOT EXISTS image_asset (
  image_id VARCHAR PRIMARY KEY,
  source_id VARCHAR NOT NULL,
  captured_at TIMESTAMPTZ,
  retrieved_at TIMESTAMPTZ NOT NULL,
  lon DOUBLE,
  lat DOUBLE,
  image_page_url VARCHAR,
  creator VARCHAR,
  license VARCHAR NOT NULL,
  attribution_text VARCHAR NOT NULL,
  local_path VARCHAR NOT NULL,
  sha256 VARCHAR NOT NULL,
  privacy_checked BOOLEAN NOT NULL DEFAULT FALSE
);

CREATE TABLE IF NOT EXISTS model_run (
  run_id UUID PRIMARY KEY,
  started_at TIMESTAMPTZ NOT NULL,
  finished_at TIMESTAMPTZ,
  model_name VARCHAR NOT NULL,
  model_version VARCHAR NOT NULL,
  prompt_version VARCHAR,
  code_commit VARCHAR,
  parameters JSON,
  input_manifest_sha256 VARCHAR,
  metrics JSON,
  notes VARCHAR
);

CREATE TABLE IF NOT EXISTS accessibility_label (
  label_id UUID PRIMARY KEY,
  image_id VARCHAR NOT NULL,
  feature_type VARCHAR NOT NULL,
  feature_value VARCHAR,
  confidence DOUBLE,
  label_source VARCHAR NOT NULL,
  run_id UUID,
  reviewer_id_hash VARCHAR,
  needs_review BOOLEAN NOT NULL DEFAULT FALSE,
  created_at TIMESTAMPTZ NOT NULL,
  FOREIGN KEY (image_id) REFERENCES image_asset(image_id),
  FOREIGN KEY (run_id) REFERENCES model_run(run_id)
);

CREATE TABLE IF NOT EXISTS od_request (
  od_id UUID PRIMARY KEY,
  origin_node_id VARCHAR NOT NULL,
  destination_node_id VARCHAR NOT NULL,
  departure_at TIMESTAMPTZ NOT NULL,
  traveler_profile VARCHAR NOT NULL,
  purpose VARCHAR,
  population_weight DOUBLE NOT NULL DEFAULT 1.0
);

CREATE TABLE IF NOT EXISTS path_candidate (
  path_id UUID PRIMARY KEY,
  od_id UUID NOT NULL,
  rank INTEGER NOT NULL,
  edge_ids JSON NOT NULL,
  expected_duration_s DOUBLE,
  generated_at TIMESTAMPTZ NOT NULL,
  FOREIGN KEY (od_id) REFERENCES od_request(od_id)
);

CREATE TABLE IF NOT EXISTS edge_reliability (
  run_id UUID NOT NULL,
  edge_id VARCHAR NOT NULL,
  time_bucket TIMESTAMPTZ NOT NULL,
  success_count INTEGER NOT NULL,
  trial_count INTEGER NOT NULL,
  probability DOUBLE NOT NULL,
  ci_low DOUBLE,
  ci_high DOUBLE,
  definition VARCHAR NOT NULL,
  PRIMARY KEY(run_id, edge_id, time_bucket)
);

CREATE TABLE IF NOT EXISTS path_reliability (
  run_id UUID NOT NULL,
  path_id UUID NOT NULL,
  method VARCHAR NOT NULL,
  journey_success_probability DOUBLE NOT NULL,
  ci_low DOUBLE,
  ci_high DOUBLE,
  scenario VARCHAR NOT NULL,
  simulations INTEGER,
  PRIMARY KEY(run_id, path_id, method, scenario)
);

CREATE TABLE IF NOT EXISTS intervention (
  intervention_id VARCHAR PRIMARY KEY,
  name VARCHAR NOT NULL,
  target_edge_ids JSON NOT NULL,
  cost_krw DOUBLE NOT NULL,
  effect_assumption JSON NOT NULL,
  evidence_url VARCHAR,
  notes VARCHAR
);

CREATE TABLE IF NOT EXISTS intervention_result (
  run_id UUID NOT NULL,
  intervention_id VARCHAR NOT NULL,
  scenario VARCHAR NOT NULL,
  baseline_successful_trips DOUBLE NOT NULL,
  post_successful_trips DOUBLE NOT NULL,
  delta_successful_trips DOUBLE NOT NULL,
  delta_per_100m_krw DOUBLE NOT NULL,
  ci_low DOUBLE,
  ci_high DOUBLE,
  PRIMARY KEY(run_id, intervention_id, scenario)
);

CREATE TABLE IF NOT EXISTS quality_check (
  check_id UUID PRIMARY KEY,
  run_id UUID,
  checked_at TIMESTAMPTZ NOT NULL,
  dataset_name VARCHAR NOT NULL,
  check_name VARCHAR NOT NULL,
  status VARCHAR NOT NULL,
  observed_value DOUBLE,
  threshold_value DOUBLE,
  details VARCHAR
);

CREATE TABLE IF NOT EXISTS prompt_log (
  prompt_id UUID PRIMARY KEY,
  run_id UUID,
  tool_name VARCHAR NOT NULL,
  scope VARCHAR NOT NULL,
  prompt_text VARCHAR NOT NULL,
  used_at TIMESTAMPTZ NOT NULL,
  human_validated BOOLEAN NOT NULL DEFAULT FALSE,
  notes VARCHAR
);
